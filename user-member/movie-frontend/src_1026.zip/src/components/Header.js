import React from "react";
import { MdLocalMovies } from "react-icons/md";
import { Link } from "react-router-dom";
import styles from "./Header.module.css";
import styled from 'styled-components';
import Responsive from './common/Responsive';
import Button from './common/Button';
import HeaderContainer from "../containers/common/HeaderContainer";

const HeaderBlock = styled.div`
  position: fixed;
  width: 100%;
  background: white;
  box-shadow: 0px 2px 4px rgba(0, 0, 0, 0.08);
`;
const Wrapper = styled(Responsive)`
  height: 4rem;
  display: flex;
  align-items: center;
  justify-content: space-between; /* 자식 엘리먼트 사이에 여백을 최대로 설정 */
  .logo {
    font-size: 1.125rem;
    font-weight: 800;
    letter-spacing: 2px;
  }
  .right {
    display: flex;
    align-items: center;
  }
`;

/**
 * 헤더가 fixed로 되어 있기 때문에 페이지의 컨텐츠가 4rem 아래 나타나도록 해주는 컴포넌트
 */
const Spacer = styled.div`
  height: 4rem;
`;

const UserInfo = styled.div`
  font-weight: 800;
  margin-right: 1rem;
`;


function Header(props,user,onLogout) {
  return (

    <header className={styles.header1}>

      <div className={styles.logo}>
        <Link to="/">
          <h1 className={styles.home}>
            Movie<span className={styles.view}>View</span>
          </h1>
        </Link>
      </div>
      <ul>
        <li>
          <Link className="page1" to="/upcoming">
            <MdLocalMovies />
            개봉예정작
          </Link>

        </li>
          <HeaderContainer/>
      </ul>

    </header>
  );
}

export default Header;
