import {Route,Routes} from 'react-router-dom';


import LoginPage from './pages/LoginPage';
import RegisterPage from './pages/RegisterPage';
import PostListPage from './pages/PostListPage';
import RegisterUpdatePage from './pages/RegisterUpdatePage';
import './App.css';

const App =() =>{
  return (
    <Routes>
      <Route path = "/" element={<PostListPage/>}/>
      <Route path = "/login" element={<LoginPage/>}/>
      <Route path = "/register" element={<RegisterPage/>}/>
      <Route path = "/registerupdate" element={<RegisterUpdatePage/>}/>


    </Routes>
  );
}

export default App;
